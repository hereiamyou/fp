# Animated Search Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/chouaibblgn45/pen/rzewrO](https://codepen.io/chouaibblgn45/pen/rzewrO).

animated search box using Html and Css and JQuery 