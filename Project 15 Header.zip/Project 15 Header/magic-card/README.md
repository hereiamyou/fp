# Magic Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/kmccqnpk/pen/QWreOOv](https://codepen.io/kmccqnpk/pen/QWreOOv).

Yet another glowing card