# Animated Login Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/JjoWVmx](https://codepen.io/alvaromontoro/pen/JjoWVmx).

This animated login form is built just with HTML and CSS. No SVG, no JavaScript, no GreenSock. The character smiles when the login form is correct.

[Read this dev.to post for more details and some catches](https://dev.to/alvaromontoro/building-an-interactive-login-form-with-html-and-css-1i2n) (e.g. the show password functionality only works on Chrome and Webkit browsers).

