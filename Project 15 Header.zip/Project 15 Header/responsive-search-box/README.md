# Responsive search box

A Pen created on CodePen.io. Original URL: [https://codepen.io/meericcartman/pen/GpJavw](https://codepen.io/meericcartman/pen/GpJavw).

A responsive search box in pure html and css that works on all browsers.