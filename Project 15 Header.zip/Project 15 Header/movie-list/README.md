# Movie List

A Pen created on CodePen.io. Original URL: [https://codepen.io/travisw/pen/BQNabp](https://codepen.io/travisw/pen/BQNabp).

An HTML and CSS prototype of Vitaly Yaskevich's dribble shot https://dribbble.com/shots/3066050-Movies-List